﻿namespace DependencyInjectionCore.Entities
{
    public class Card
    {
        public int Id { get; set; }
        public string CardNumber { get; set; }

    }
}
