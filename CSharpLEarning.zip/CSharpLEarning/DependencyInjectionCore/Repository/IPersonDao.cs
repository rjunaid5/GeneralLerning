﻿using DependencyInjectionCore.Entities;

namespace DependencyInjectionCore.Repository
{
    public interface IPersonDao
    {
        List<Person> GetPerson();
    }
}
