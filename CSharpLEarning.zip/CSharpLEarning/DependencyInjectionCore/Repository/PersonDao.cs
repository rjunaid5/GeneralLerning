﻿using DependencyInjectionCore.Entities;

namespace DependencyInjectionCore.Repository
{
    public class PersonDao : IPersonDao
    {
        public List<Person> GetPerson()
        {
            return new List<Person>() { new Person() { Name = "TestUser1" , Age =21},
                                        new Person() { Name = "TestUser2", Age = 22 } };
        }
    }
}
