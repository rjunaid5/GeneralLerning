﻿namespace DependencyInjectionCore.Repository
{
    public class MyDbContext 
    {
    }
}
