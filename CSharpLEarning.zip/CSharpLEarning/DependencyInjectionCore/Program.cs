using DependencyInjectionCore.Repository;

var builder = WebApplication.CreateBuilder(args);


//Dependency Injection will result in decoupled architecture
/*changes in one place can result in many places
    builder.Services.AddScoped<MyDbContext, SqlServer>(); 
    now if in future i want to use mongodb i just change to
    builder.Services.AddScoped<MyDbContext, MongoDb>();
    it will be reflected to whole application.
IOC(Inversion of Control) do your work while delegating unnecessary things to somebody else
e.g Home controller needs just to display data, it does not need to intialize each and every classes
so above DI will do IOC
 */

//By using this injection there is no need for Perondao temp = new PersonDao();
// every time


//Lifetime of Injection
builder.Services.AddScoped<IPersonDao, PersonDao>();// For every single request from same/different user there will be new instance
builder.Services.AddTransient<IPersonDao, PersonDao>(); 
builder.Services.AddSingleton<IPersonDao, PersonDao>();// Singleton means just one instance is created and used throughout the application
// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}



app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
