﻿using DependencyInjectionCore.Models;
using DependencyInjectionCore.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DependencyInjectionCore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IPersonDao _personDao;


        //Dependency Injection
        /// <summary>
        /// Home controller Has only function to display data, it doesnot need to initialized
        /// PersonDao, so By using DI it will let someone else do initialization
        /// Home controller is not creating instance of PersonDao, instead we are injecting into Controller class
        /// Without resolving this Dependency we will get an error(Resolving means creating instance)
        /// </summary>
        /// <param name="logger"></param>

        public HomeController(ILogger<HomeController> logger, IPersonDao personDao)
        {
            _logger = logger;
            _personDao = personDao;

            // _personDao = new PersonDao 
            ///
            /// why we dont do like that because later on PersonDao can be changed so we have to change
            /// on every controller
            ///
        }

        public string Index()
        {
            return _personDao.GetPerson().FirstOrDefault()?.Name;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}